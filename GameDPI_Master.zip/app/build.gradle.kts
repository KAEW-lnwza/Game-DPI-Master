plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gamedpi.master"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gamedpi.master"
        minSdk = 24
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures {
        // จำเป็นสำหรับ AIDL interface ของ Shizuku (IUserService / IRemoteProcess)
        aidl = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    // Shizuku API: คลาส Shizuku (เรียกคำสั่งผ่าน binder)
    implementation("dev.rikka.shizuku:api:13.1.5")
    // Shizuku Provider: คลาส rikka.shizuku.ShizukuProvider ที่ประกาศใน AndroidManifest.xml
    // หากขาด dependency ตัวนี้ ตอนเปิดแอปจะ crash ทันทีด้วย ClassNotFoundException
    // (manifest เก็บชื่อคลาสเป็น string จึง build ผ่านแต่ตอน runtime หาคลาสไม่เจอ)
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
