# รายงานการแก้ไขโปรเจกต์ Game DPI Master

ปัญหาเดิม: Build APK ผ่าน GitHub Actions ได้ แต่เมื่อติดตั้งบนมือถือแล้วเปิดแอป เด้งออกทันที
ขอบเขต: แก้สาเหตุที่ทำให้เด้งจริง โดยไม่ลบฟังก์ชัน/หน้าจอเดิม และไม่เรียกคำสั่งปรับ DPI อัตโนมัติตอนเปิดแอป

> หมายเหตุความตรงไปตรงมา: ในสภาพแวดล้อมของผู้ช่วยไม่มี Android SDK / Gradle / JDK 17 / อุปกรณ์ Android จึง **ยังไม่ได้ Build APK จริงและยังไม่ได้ทดสอบบนเครื่อง** เอกสารนี้แยกให้ชัดว่าส่วนใดตรวจสอบแล้วด้วยวิธีใด และส่วนใดต้องรันบนเครื่องจริง (หัวข้อ 4–6)

---

## 1. สาเหตุที่พบ (เรียงตามความรุนแรง)

### RC-1 (สาเหตุหลักที่ทำให้เด้งทันทีตอนเปิด): ขาด dependency `provider` ของ Shizuku
- `app/build.gradle.kts` เดิมประกาศเฉพาะ `dev.rikka.shizuku:api:13.1.5`
- แต่ `AndroidManifest.xml` ประกาศ `<provider android:name="rikka.shizuku.ShizukuProvider" ... />`
- คลาส `rikka.shizuku.ShizukuProvider` อยู่ในอาร์ติแฟกต์แยกต่างหากคือ `dev.rikka.shizuku:provider:13.1.5`
- **หลักฐานจากไฟล์จริง (ดาวน์โหลด AAR จาก Maven Central มาตรวจ bytecode):**
  - `api-13.1.5.aar` → `classes.jar` มี `rikka/shizuku/Shizuku.class` แต่ **ไม่มี** `ShizukuProvider.class`
  - `provider-13.1.5.aar` → มี `rikka/shizuku/ShizukuProvider.class` (7,783 bytes)
- กลไกการ crash: ก่อนสร้าง Activity ระบบจะ instantiate provider ตาม manifest ทันที หาคลาสไม่เจอ → `java.lang.ClassNotFoundException: rikka.shizuku.ShizukuProvider` → `RuntimeException: Unable to get provider ...` → แอปเด้งก่อนถึง `onCreate()`
- Build ผ่านได้เพราะชื่อคลาสใน manifest เป็นข้อความ string ไม่มีการตรวจ compile-time
- เอกสารทางการของ Shizuku ระบุว่าต้องเพิ่มทั้ง `api` และ `provider`

### RC-2: เรียก API Shizuku โดยไม่ป้องกันข้อยกเว้น และไม่มี listener รับผลขอสิทธิ์
- เดิมเรียก `Shizuku.pingBinder()` / `checkSelfPermission()` / `requestPermission()` ตรง ๆ ถ้า binder อยู่ในสถานะไม่คาดหวังอาจ throw
- ไม่ได้ลงทะเบียน `OnRequestPermissionResultListener` ผลการขอสิทธิ์จึงไม่แสดงกลับให้ผู้ใช้ทราบ

### RC-3: ใช้ reflection เรียก `newProcess` แทน API จริง
- เดิมใช้ `getDeclaredMethod("newProcess", ...)` ผูกกับลายเซ็นภายในของคลาส เสี่ยง `NoSuchMethodException` ถ้าเวอร์ชันเปลี่ยน
- ตรวจแล้วว่าใน 13.1.5 มีเมธอดจริง `Shizuku.newProcess(String[], String[], String)` คืนค่า `ShizukuRemoteProcess` (ซึ่งเป็น subclass ของ `Process`) จึงเรียกตรงได้

### RC-4: ไม่มีข้อความสถานะเมื่อ Shizuku ยังไม่พร้อม และไม่มีคำเตือนชัดเจน
- ผู้ใช้ต้องการ: ถ้า Shizuku ยังไม่พร้อมให้แสดงข้อความแทนการเด้ง / เปิดหน้าหลักได้ตามปกติ / ขอสิทธิ์ได้ถ้ายังไม่อนุญาต

### RC-5 (เสริมป้องกัน): โค้ดตกแต่งแถบระบบไม่มี try/catch
- `applySystemBars()` อาจพังบนบาง ROM ได้ จึงห่อทั้งฟังก์ชันด้วย try/catch เพื่อไม่กระทบการเปิดหน้าแอป

---

## 2. ไฟล์ที่แก้ไขแล้ว

| # | ไฟล์ | การเปลี่ยนแปลง | แก้ปัญหา |
|---|------|----------------|----------|
| 1 | `app/build.gradle.kts` | เพิ่ม `implementation("dev.rikka.shizuku:provider:13.1.5")`; เพิ่ม `buildFeatures { aidl = true }` | RC-1, RC-3 (AIDL ของ Shizuku ถูก compile) |
| 2 | `app/src/main/java/com/gamedpi/master/MainActivity.kt` | (ก) เพิ่ม listener `BinderReceived/Dead/RequestPermissionResult` ลงทะเบียนใน `onCreate` และถอดใน `onDestroy` ทุกจุดห่อ try/catch (ข) เพิ่มฟังก์ชันปลอดภัย `shizukuReady()` / `shizukuPermissionGranted()` / `refreshShizukuStatus()` (ค) เปลี่ยน `applySystemDpi` ใช้ `Shizuku.newProcess(...)` ตรง ๆ แทน reflection, ตรวจ null process, `destroy()` ใน finally (ง) เพิ่มข้อความสถานะ Shizuku 3 ระดับบนทั้งหน้ารายการแอปและหน้าตั้งค่า DPI (จ) ห่อ `applySystemBars()` ด้วย try/catch | RC-2, RC-3, RC-4, RC-5 |
| 3 | `app/src/main/AndroidManifest.xml` | ตรวจสอบแล้วว่าโครงสร้าง provider ถูกต้องตามเอกสาร Shizuku (authorities, permission, exported, enabled, multiprocess); **ไม่ต้องแก้ logic** — provider จะทำงานได้เมื่อมี dependency `provider` ครบตามข้อ 1 | RC-1 (ทำให้ประกาศเดิมใช้งานได้จริง) |
| 4 | `README.md` | เพิ่มส่วนอ้างอิงรายงานการแก้ไข | เอกสารประกอบ |
| 5 | `FIX_REPORT.md` (ไฟล์ใหม่) | รายงานฉบับนี้ | เอกสารประกอบ |

**สิ่งที่ไม่ได้ลบ/ไม่ได้เปลี่ยนแปลง:** หน้ารายการแอป, หน้าตั้งค่า DPI, ปุ่มทุกปุ่ม, ธีมดำ/ขาว, พื้นหลังอนิเมะ, การบันทึกโปรไฟล์ DPI ลง SharedPreferences, ลิงก์ TikTok และลักษณะ UI เดิมทั้งหมด

**พฤติกรรมใหม่ที่รับประกันตามโค้ด:**
- `onCreate()` มีเพียงการอ่านค่า theme, ลงทะเบียน listener (ห่อ try/catch) และสร้างหน้ารายการแอป — **ไม่มีการเรียกคำสั่ง `wm density` หรือปรับ DPI ใด ๆ ตอนเปิดแอป** (ตรวจด้วยการสแกนโค้ดแล้วว่าไม่มี)
- เปิดแอปได้แม้จะยังไม่ติดตั้ง/ไม่เริ่ม Shizuku: แสดงข้อความสถานะ + Toast แทนการเด้ง
- กดปุ่มขอสิทธิ์ได้เสมอ; ผลอนุญาต/ไม่อนุญาตแสดงผ่าน listener และอัปเดตข้อความสถานะ

---

## 3. การตรวจสอบที่ทำในสภาพแวดล้อมนี้ (static verification)

| รายการ | วิธีตรวจ | ผล |
|---|---|---|
| ไฟล์ XML well-formed (manifest, colors, launcher) | Python `xml.etree` parse ทั้ง 3 ไฟล์ | ผ่านทั้งหมด |
| คู่วงเล็บ `{}` `()` `[]` ใน MainActivity.kt | นับจำนวนเปิด/ปิด | ผ่าน (197/197, 764/764, 27/27) |
| ไม่เหลือ reflection `getDeclaredMethod` | ค้นข้อความในไฟล์ | 0 จุด |
| `onCreate()` ไม่เรียก `applySystemDpi` | แยกขอบโค้ด onCreate มาสแกน | ไม่เรียก (ไม่สั่ง DPI ตอนเปิด) |
| Resource ที่อ้างถึง (`R.drawable.profile`, `@mipmap/ic_launcher`, `@drawable/ic_launcher_foreground`, `@color/ic_launcher_background`) เทียบกับไฟล์จริงใน `res/` | cross-check | ครบทุกตัว |
| เมธอด Shizuku ที่เรียกมีจริงใน bytecode `api-13.1.5.aar` | ดาวน์โหลด AAR + อ่าน strings ของ `Shizuku.class` | `pingBinder`, `checkSelfPermission`, `requestPermission`, `newProcess`, `addBinderReceivedListenerSticky`, `addBinderDeadListener`, `addRequestPermissionResultListener`, และ remove ทั้งหมด มีจริง |
| อินเทอร์เฟซ listener มีเมธอดที่ lambda ใช้ | อ่าน `Shizuku$On*.class` | `onBinderReceived()`, `onBinderDead()`, `onRequestPermissionResult(int,int)` ตรงกับที่ใช้ |
| มีคลาส `ShizukuProvider` ใน provider AAR | unzip `provider-13.1.5.aar` | พบ `rikka/shizuku/ShizukuProvider.class` |
| พิกัด dependency บน Maven Central | HTTP GET POM/AAR | api และ provider ทั้ง POM/AAR คืน 200 |
| Transitive dependencies (`aidl`, `shared`, `androidx.annotation:1.3.0`) | อ่าน POM | มาจาก Gradle โดยอัตโนมัติจาก repositories ที่ประกาศไว้แล้ว |

> ข้อจำกัด: ไม่มี `kotlinc` จึงไม่ได้ compile Kotlin ตัวจริง; การตรวจจึงเป็นการตรวจ syntax/ความสมดุลของวงเล็บ การอ้างอิง API เทียบ bytecode จริง และความถูกต้องของ manifest/resource ไม่ใช่การ compile ทั้งโปรเจกต์

---

## 4. สถานะการ Build (ไม่กล่าวอ้างว่าผ่าน)

สภาพแวดล้อมนี้ไม่มีเครื่องมือต่อไปนี้ จึง **รัน `gradle assembleDebug --no-daemon --stacktrace` ไม่ได้จริง**:
- ไม่มี Android SDK (ต้องการ compileSdk 35 + build-tools)
- ไม่มี Gradle และไม่มี Gradle wrapper ใน ZIP ต้นทาง
- มีเพียง JDK 11 ส่วน AGP 8.7.3 ต้องการ JDK 17
- ไม่มีอุปกรณ์/emulator Android

### คำสั่ง Build ที่ควรรันจริง (บนเครื่องที่มี Android Studio หรือ CI ที่ตั้งค่าไว้)
```bash
# บนเครื่องที่ติดตั้ง JDK 17 + Android SDK 35 แล้ว
./gradlew assembleDebug --no-daemon --stacktrace
# หรือถ้ายังไม่มี wrapper:
gradle assembleDebug --no-daemon --stacktrace
```
- GitHub Actions เดิมที่ Build ผ่านอยู่แล้ว: หลังเพิ่ม dependency `provider` Gradle จะดึง AAR มาเองโดยไม่ต้องตั้งค่าเพิ่ม
- ผล APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

---

## 5. รายการทดสอบบนเครื่องจริง (ยังไม่ได้ดำเนินการ ต้องทำหลัง Build ได้)

| # | การทดสอบ | คาดหวัง |
|---|---|---|
| 1 | ติดตั้ง APK แล้วแตะเปิด โดยยังไม่ติดตั้ง Shizuku | เปิดหน้ารายการแอปได้ ไม่เด้ง; เห็นข้อความ "ยังไม่เชื่อมต่อ" |
| 2 | กดปุ่ม "เชื่อมต่อ / ขอสิทธิ์ Shizuku" ตอนไม่มี Shizuku | ขึ้น Toast แนะนำให้เปิด Shizuku ก่อน ไม่เด้ง |
| 3 | เปิดแอป Shizuku และเริ่มการทำงาน แล้วกลับมากดปุ่ม | สถานะเปลี่ยนเป็น "เชื่อมต่อแล้ว แต่ยังไม่อนุญาตสิทธิ์" |
| 4 | กดขอสิทธิ์แล้วกดอนุญาตใน Shizuku | Toast ยืนยัน + สถานะเปลี่ยนเป็น "พร้อมใช้งาน" |
| 5 | กรอกค่า DPI แล้วกด "ใช้ค่า DPI นี้กับระบบ (Shizuku)" | คำสั่ง `wm density <ค่า>` ทำงานผ่าน Shizuku; ดูผลผ่าน `logcat` |
| 6 | กรอกค่านอกช่วง 1–2000 | Toast แจ้งช่วงค่าที่ยอมรับ ไม่รันคำสั่ง |
| 7 | ปิดแล้วเปิดแอปใหม่ / สลับธีมดำ-ขาว / กลับหน้ารายการแอป | ไม่เด้ง; โปรไฟล์ DPI ที่บันทึกไว้ยังอยู่ |
| 8 | ตรวจ `logcat` | ไม่มี `FATAL EXCEPTION`, `ClassNotFoundException`, `ShizukuProvider` error |

หมายเหตุ: โปรเจกต์นี้ไม่มีระบบ "ลองดึงเงาสูงสุด 3 ครั้ง" หรือระบบ RPG จากข้อความสเปกโปรเจกต์อื่น (นโยบายคนละโปรเจกต์) จึงไม่มีรายการทดสอบส่วนนั้น

---

## 6. สิ่งที่ยังไม่เสร็จ / ข้อจำกัดที่ควรทราบ

1. **ยังไม่มี APK ที่ Build ผ่านในสภาพแวดล้อมนี้** ต้องรัน build บน Android Studio/CI ตามหัวข้อ 4
2. **ยังไม่ได้ทดสอบบนมือถือจริง** โดยเฉพาะผลของคำสั่ง `wm density` ผ่าน Shizuku จริง และความเสถียรบน Android หลายเวอร์ชัน
3. `targetSdk` คงไว้ที่ 28 ตามโปรเจกต์เดิม (ข้อกำหนดให้รักษาฟังก์ชันเดิม) หากจะเผยแพร่ Play Store ภายหลังอาจต้องพิจารณาปรับ targetSdk
4. ไม่ได้เพิ่มปุ่ม `wm density reset` เพราะไม่มีในเวอร์ชันเดิม และอยู่นอกขอบเขตการแก้บั๊กครั้งนี้ (สามารถขอเพิ่มได้ภายหลัง)

---

## 7. ความสัมพันธ์กับผลลัพธ์ที่ผู้ขอระบุ

| ผลลัพธ์ที่ขอ | สถานะ |
|---|---|
| 1. แก้ไขไฟล์โปรเจกต์จริง | ดำเนินการแล้ว (หัวข้อ 2) |
| 2. ตรวจว่าโค้ด Kotlin ไม่มี Compile Error | ตรวจ static แล้ว (หัวข้อ 3); ยังไม่ใช่การ compile จริง ไม่กล่าวอ้างว่าคอมไพล์ผ่าน |
| 3. ทดลอง Build `gradle assembleDebug --no-daemon --stacktrace` | รันไม่ได้ใน sandbox; ให้คำสั่งและเงื่อนไขที่ต้องมี (หัวข้อ 4) |
| 4. ส่งโปรเจกต์ที่แก้แล้วเป็น ZIP | ส่งเป็นไฟล์ `GameDPI_Master_fixed.zip` |
| 5. สรุปไฟล์ที่แก้และปัญหาที่แก้ | หัวข้อ 1–2 ของรายงานนี้ |
