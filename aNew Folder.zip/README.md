# Game DPI Master

Android Studio project (Kotlin).

## Features
- Lists only downloaded (non-system) applications, with a search box (by name or package).
- Select an app and enter a DPI profile value.
- Saves the value separately by package name using SharedPreferences.
- Launches the selected app from its settings screen.
- Can clear a saved profile.

- Animated anime-style background (moon/sun glow, twinkling stars, falling sakura petals, layered waves).
- Dark / Light mode switch (saved automatically).
- Press effects on buttons and list items.
- App icon and header avatar use the bundled profile photo.

## Shizuku (real DPI change)
The app talks to Shizuku and runs `wm density <value>` (device-wide) right before launching the selected app.
The value stays (even after reboot) until you press "คืนค่า DPI" in the app, which runs `wm density reset`.
Setup guide is inside the app (📖 คู่มือ Shizuku). Video guide: https://vt.tiktok.com/ZSshrLobP/
Android has no public API for a per-app density, so the change applies to the whole device.
Safe range is 120-900 DPI. If the screen ever becomes unusable: `adb shell wm density reset`.

## Credits
Made by kaew_king - TikTok: https://www.tiktok.com/@k_a_e_w.01

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build APK(s).

Package: `com.gamedpi.master`
