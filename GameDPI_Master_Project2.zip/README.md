# Game DPI Master — Shizuku update

Developer: **kaew_kung**

## What changed
- Added Shizuku API integration and permission/provider declarations.
- Added a connect/request-permission button.
- Added an explicit action to run `wm density <value>` through Shizuku.
- Added TikTok contact and tutorial links.

## Important DPI behavior
The app's saved DPI profile is associated with the selected app, but Android's `wm density` command changes **system-wide display density**, not only the selected game. Use it carefully. The value range accepted by the app is 1–2000. Restore the device's default density using Android's Display size settings or Shizuku command `wm density reset`.

## Connect
1. Install and open Shizuku.
2. Start Shizuku using the method available on your Android version (wireless debugging or root).
3. Open Game DPI Master and tap **เชื่อมต่อ / ขอสิทธิ์ Shizuku**.
4. Approve the permission dialog in Shizuku.
5. Enter a DPI value and tap **ใช้ค่า DPI นี้กับระบบ (Shizuku)**.

## Links
- Developer TikTok: https://www.tiktok.com/@k_a_e_w.01
- Shizuku connection guide: https://vt.tiktok.com/ZSsrG4UAQ/
