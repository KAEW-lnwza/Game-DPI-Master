# Game DPI Master

Android Studio project (Kotlin).

## Features
- Lists only downloaded (non-system) applications, with a search box (by name or package).
- Select an app and enter a DPI profile value.
- Saves the value separately by package name using SharedPreferences.
- Launches the selected app from its settings screen.
- Can clear a saved profile.

- Animated anime-style background (moon/sun glow, twinkling stars, falling sakura petals, layered waves).
- Dark / Light mode switch (saved automatically).
- Press effects on buttons and list items.
- App icon and header avatar use the bundled profile photo.

## Important limitation
This starter app stores a per-app DPI profile and launches the chosen app. It does **not** change another app's actual Android display density. Standard Android apps cannot set another app's density independently through a public API. Actual per-app DPI requires suitable OS/root/framework support or changes inside the target app.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build APK(s).

Package: `com.gamedpi.master`
