plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gamedpi.master"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gamedpi.master"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
