package com.gamedpi.master

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("profiles", MODE_PRIVATE) }
    private var selected: AppEntry? = null
    private lateinit var root: LinearLayout

    data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showAppList()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun makeRoot(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(12, 17, 28))
        }
        setContentView(root)
        return root
    }

    private fun title(text: String, size: Float = 23f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, dp(14))
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.rgb(42, 103, 230))
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { action() }
        }

    private fun showAppList() {
        selected = null
        makeRoot()
        root.addView(title("Game DPI Master"))
        root.addView(TextView(this).apply {
            text = "เลือกแอปหรือเกมที่ต้องการตั้งค่า DPI"
            textSize = 15f; setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(12))
        })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val apps = try {
            packageManager.getInstalledApplications(0)
                .filter { it.packageName != packageName }
                .mapNotNull {
                    try {
                        AppEntry(
                            packageManager.getApplicationLabel(it).toString(),
                            it.packageName,
                            packageManager.getApplicationIcon(it)
                        )
                    } catch (_: Exception) { null }
                }.sortedBy { it.label.lowercase() }
        } catch (_: Exception) { emptyList() }

        if (apps.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "ไม่พบแอปที่ติดตั้ง"; setTextColor(Color.WHITE)
            })
        }
        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(Color.rgb(25, 33, 48))
                }
            }
            val icon = ImageView(this).apply { setImageDrawable(app.icon) }
            row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
            val text = TextView(this).apply {
                this.text = app.label + "\n" + (if (prefs.contains(key(app))) "บันทึก DPI: " + prefs.getInt(key(app), 0) else "ยังไม่ได้ตั้งค่า")
                textSize = 15f; setTextColor(Color.WHITE)
                setPadding(dp(12), 0, dp(8), 0)
            }
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = "›"; textSize = 28f; setTextColor(Color.LTGRAY)
            })
            row.setOnClickListener { selected = app; showSettings(app) }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            list.addView(row, lp)
        }
    }

    private fun key(app: AppEntry) = "dpi_" + app.packageName

    private fun showSettings(app: AppEntry) {
        makeRoot()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(ImageView(this).apply { setImageDrawable(app.icon) },
            LinearLayout.LayoutParams(dp(48), dp(48)))
        head.addView(TextView(this).apply {
            text = app.label; textSize = 21f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; setPadding(dp(12), 0, 0, 0)
        })
        root.addView(head)
        root.addView(TextView(this).apply {
            text = app.packageName; textSize = 12f; setTextColor(Color.GRAY)
            setPadding(0, dp(8), 0, dp(18))
        })
        root.addView(title("ตั้งค่า DPI", 20f))
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            textSize = 25f
            gravity = Gravity.CENTER
            hint = "เช่น 600"
            setHintTextColor(Color.GRAY)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.rgb(25, 33, 48))
                setStroke(dp(1), Color.rgb(65, 80, 105))
            }
            val saved = prefs.getInt(key(app), 0)
            if (saved > 0) setText(saved.toString())
        }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(64)))
        root.addView(TextView(this).apply {
            text = "ค่าที่บันทึกจะผูกกับแอปนี้เท่านั้น\nหมายเหตุ: ค่านี้เป็นโปรไฟล์ DPI ในแอป ไม่ได้เปลี่ยน DPI ระบบของเกมโดยตรง"
            textSize = 13f; setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, dp(18))
        })
        root.addView(button("บันทึกการตั้งค่า") {
            val value = input.text.toString().toIntOrNull()
            if (value == null || value !in 1..2000) {
                Toast.makeText(this, "กรุณากรอก DPI ระหว่าง 1 ถึง 2000", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putInt(key(app), value).apply()
                Toast.makeText(this, "บันทึก DPI $value แล้ว", Toast.LENGTH_SHORT).show()
                showSettings(app)
            }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        root.addView(button("เข้าเกม ${app.label}") { launchApp(app) },
            LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        root.addView(button("ลบการตั้งค่า DPI") {
            prefs.edit().remove(key(app)).apply()
            Toast.makeText(this, "ลบโปรไฟล์แล้ว", Toast.LENGTH_SHORT).show()
            showSettings(app)
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        root.addView(button("กลับไปเลือกรายชื่อแอป") { showAppList() },
            LinearLayout.LayoutParams(-1, dp(54)))
    }

    private fun launchApp(app: AppEntry) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            Toast.makeText(this, "แอปนี้ไม่มีหน้าสำหรับเปิดจาก Launcher", Toast.LENGTH_LONG).show()
        } else {
            try {
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "เปิดแอปไม่สำเร็จ", Toast.LENGTH_LONG).show()
            }
        }
    }
}
