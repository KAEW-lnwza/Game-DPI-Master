package com.gamedpi.master

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.content.pm.ApplicationInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Random
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import rikka.shizuku.Shizuku

private const val TWO_PI = 6.2831855f

/** ชุดสีของแต่ละโหมด */
class Pal(
    val skyTop: Int,
    val card: Int,
    val cardStroke: Int,
    val fg: Int,
    val fgSub: Int,
    val fgHint: Int,
    val accentA: Int,
    val accentB: Int,
    val inputBg: Int,
    val danger: Int
)

val DARK_PAL = Pal(
    skyTop = Color.parseColor("#04050C"),
    card = Color.argb(185, 18, 22, 40),
    cardStroke = Color.argb(95, 150, 130, 255),
    fg = Color.parseColor("#F4F5FA"),
    fgSub = Color.parseColor("#A9B0C8"),
    fgHint = Color.parseColor("#7C84A0"),
    accentA = Color.parseColor("#7C5CFF"),
    accentB = Color.parseColor("#FF5CA8"),
    inputBg = Color.argb(205, 12, 16, 32),
    danger = Color.parseColor("#FF4D6D")
)

val LIGHT_PAL = Pal(
    skyTop = Color.parseColor("#FFF0F6"),
    card = Color.argb(220, 255, 255, 255),
    cardStroke = Color.argb(130, 175, 165, 230),
    fg = Color.parseColor("#1B1F33"),
    fgSub = Color.parseColor("#5A6285"),
    fgHint = Color.parseColor("#8A91AE"),
    accentA = Color.parseColor("#6C5CE7"),
    accentB = Color.parseColor("#FF7EB6"),
    inputBg = Color.argb(240, 255, 255, 255),
    danger = Color.parseColor("#E5395B")
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("profiles", MODE_PRIVATE) }
    private var selected: AppEntry? = null
    private lateinit var root: LinearLayout
    private var searchQuery = ""
    private var dark = true
    private var frame: FrameLayout? = null
    private var bgDark = true
    private var redraw: () -> Unit = {}

    private val pal: Pal
        get() = if (dark) DARK_PAL else LIGHT_PAL

    data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("dark", true)
        showAppList()
    }

    override fun onBackPressed() {
        if (selected != null) showAppList() else super.onBackPressed()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- โหมดสี / system bars ----------

    private fun setMode(makeDark: Boolean) {
        dark = makeDark
        getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("dark", makeDark).apply()
        redraw()
    }

    private fun applySystemBars() {
        val p = pal
        window.statusBarColor = p.skyTop
        window.navigationBarColor = p.skyTop
        var flags = window.decorView.systemUiVisibility
        flags = if (dark) {
            flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        } else {
            flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun makeRoot(): LinearLayout {
        applySystemBars()
        val existing = frame
        val f: FrameLayout
        if (existing == null || bgDark != dark) {
            f = FrameLayout(this)
            f.addView(AnimeBackgroundView(this, dark), FrameLayout.LayoutParams(-1, -1))
            frame = f
            bgDark = dark
            setContentView(f)
        } else {
            f = existing
            f.removeView(root)
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        f.addView(root, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    // ---------- helper สำหรับพื้นหลัง/ปุ่ม ----------

    private fun cardBg(r: Float): GradientDrawable = GradientDrawable().apply {
        cornerRadius = r
        setColor(pal.card)
        setStroke(dp(1), pal.cardStroke)
    }

    private fun accentBg(r: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.accentA, pal.accentB)).apply {
            cornerRadius = r
        }

    private fun outlineBg(r: Float, strokeColor: Int, fillColor: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = r
        setColor(fillColor)
        setStroke(dp(1), strokeColor)
    }

    /** เอฟเฟกต์ตอนกด: ย่อเล็กน้อย + จางลง แล้วเด้งกลับ */
    private fun pressable(v: View) {
        v.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.95f).scaleY(0.95f).alpha(0.85f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(160).start()
            }
            false
        }
    }

    private fun heading(label: String, size: Float): TextView = TextView(this).apply {
        this.text = label
        textSize = size
        setTextColor(pal.fg)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(2), dp(18), 0, dp(8))
    }

    private fun button(label: String, kind: Int = 0, action: () -> Unit): TextView = TextView(this).apply {
        this.text = label
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        isClickable = true
        setPadding(dp(12), dp(8), dp(12), dp(8))
        when (kind) {
            0 -> {
                setTextColor(Color.WHITE)
                background = accentBg(dp(16).toFloat())
            }
            2 -> {
                setTextColor(pal.danger)
                background = outlineBg(dp(16).toFloat(), pal.danger, Color.TRANSPARENT)
            }
            else -> {
                setTextColor(pal.fg)
                background = outlineBg(dp(16).toFloat(), pal.cardStroke, pal.card)
            }
        }
        setOnClickListener { action() }
        pressable(this)
    }


    private val shizukuRequestCode = 7412

    private fun openLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "ไม่สามารถเปิดลิงก์ได้", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "กรุณาเปิด Shizuku และเริ่มการทำงานก่อน", Toast.LENGTH_LONG).show()
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "เชื่อมต่อ Shizuku แล้ว", Toast.LENGTH_SHORT).show()
        } else {
            Shizuku.requestPermission(shizukuRequestCode)
        }
    }

    private fun applySystemDpi(value: Int) {
        if (value !in 1..2000) {
            Toast.makeText(this, "ค่า DPI ต้องอยู่ระหว่าง 1 ถึง 2000", Toast.LENGTH_LONG).show()
            return
        }

        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "เปิด Shizuku แล้วกดเชื่อมต่อก่อน", Toast.LENGTH_LONG).show()
            return
        }

        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(shizukuRequestCode)
            Toast.makeText(this, "อนุญาต Shizuku แล้วกดใช้ DPI อีกครั้ง", Toast.LENGTH_LONG).show()
            return
        }

        Thread {
            try {
                val command = arrayOf("wm", "density", value.toString())

                val method = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )

                method.isAccessible = true

                val process = method.invoke(
                    null,
                    command,
                    null,
                    null
                ) as Process

                val exit = process.waitFor()

                runOnUiThread {
                    if (exit == 0) {
                        Toast.makeText(
                            this,
                            "ตั้งค่า DPI ระบบเป็น $value สำเร็จ",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this,
                            "คำสั่ง DPI ไม่สำเร็จ (รหัส $exit)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "ใช้คำสั่งผ่าน Shizuku ไม่สำเร็จ: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val token = currentFocus?.windowToken
        if (token != null) imm.hideSoftInputFromWindow(token, 0)
    }

    // ---------- แถบบน: โปรไฟล์ (รูปไก่) + ชื่อแอป + สวิตช์โหมด ----------

    private fun avatar(): View {
        val ring = FrameLayout(this).apply {
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(pal.accentA, pal.accentB)
            ).apply { shape = GradientDrawable.OVAL }
        }
        val img = ImageView(this).apply {
            setImageResource(R.drawable.profile)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
        }
        ring.addView(img, FrameLayout.LayoutParams(-1, -1))
        return ring
    }

    private fun modeToggle(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = cardBg(dp(18).toFloat())
        }
        fun seg(label: String, active: Boolean, makeDark: Boolean): TextView = TextView(this).apply {
            this.text = label
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(11), dp(6), dp(11), dp(6))
            if (active) {
                setTextColor(Color.WHITE)
                background = accentBg(dp(15).toFloat())
            } else {
                setTextColor(pal.fgSub)
            }
            setOnClickListener { if (dark != makeDark) setMode(makeDark) }
            pressable(this)
        }
        box.addView(seg("☾ ดำ", dark, true))
        box.addView(seg("☀ ขาว", !dark, false))
        return box
    }

    private fun topBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(avatar(), LinearLayout.LayoutParams(dp(48), dp(48)))
        bar.addView(TextView(this).apply {
            this.text = "Game DPI Master\nผู้พัฒนา: kaew_kung"
            textSize = 17f
            setTextColor(pal.fg)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(modeToggle())
        return bar
    }

    // ---------- หน้ารายการแอป ----------

    private fun loadDownloadedApps(): List<AppEntry> = try {
        packageManager.getInstalledApplications(0)
            .filter { it.packageName != packageName }
            // เอาเฉพาะแอปที่ผู้ใช้ติดตั้งเอง (ตัดแอประบบออก)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .mapNotNull {
                try {
                    AppEntry(
                        packageManager.getApplicationLabel(it).toString(),
                        it.packageName,
                        packageManager.getApplicationIcon(it)
                    )
                } catch (e: Exception) { null }
            }
            .sortedBy { it.label.lowercase() }
    } catch (e: Exception) { emptyList() }

    private fun key(app: AppEntry) = "dpi_" + app.packageName

    private fun buildRow(app: AppEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = cardBg(dp(18).toFloat())
            isClickable = true
        }
        row.addView(ImageView(this).apply { setImageDrawable(app.icon) }, LinearLayout.LayoutParams(dp(44), dp(44)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
        }
        info.addView(TextView(this).apply {
            this.text = app.label
            textSize = 15f
            setTextColor(pal.fg)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            this.text = app.packageName
            textSize = 11f
            setTextColor(pal.fgHint)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))

        if (prefs.contains(key(app))) {
            row.addView(TextView(this).apply {
                this.text = "DPI " + prefs.getInt(key(app), 0)
                textSize = 12f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(10), dp(5), dp(10), dp(5))
                background = accentBg(dp(12).toFloat())
            })
        } else {
            row.addView(TextView(this).apply {
                this.text = "›"
                textSize = 26f
                setTextColor(pal.fgSub)
            })
        }

        row.setOnClickListener { showSettings(app) }
        pressable(row)
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        return row
    }

    private fun showAppList() {
        selected = null
        redraw = { showAppList() }
        makeRoot()
        root.addView(topBar())
        root.addView(TextView(this).apply {
            this.text = "เลือกเกมหรือแอปที่ดาวน์โหลดไว้ เพื่อตั้งค่า DPI"
            textSize = 14f
            setTextColor(pal.fgSub)
            setPadding(dp(2), dp(14), 0, dp(12))
        })

        val search = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            hint = "🔍  ค้นหาชื่อแอปหรือเกม"
            setHintTextColor(pal.fgHint)
            setTextColor(pal.fg)
            textSize = 16f
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(pal.inputBg)
                setStroke(dp(1), pal.cardStroke)
            }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        val countView = TextView(this).apply {
            textSize = 13f
            setTextColor(pal.fgHint)
            setPadding(dp(4), 0, 0, dp(8))
        }
        root.addView(countView)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val apps = loadDownloadedApps()

        fun render(query: String, animate: Boolean) {
            list.removeAllViews()
            val q = query.trim().lowercase()
            val shown = if (q.isEmpty()) apps else apps.filter {
                it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
            }
            countView.text = if (q.isEmpty()) "แอปที่ดาวน์โหลด ${apps.size} แอป" else "พบ ${shown.size} จาก ${apps.size} แอป"
            if (shown.isEmpty()) {
                list.addView(TextView(this).apply {
                    this.text = if (apps.isEmpty()) "ไม่พบแอปที่ดาวน์โหลดไว้" else "ไม่พบแอปที่ตรงกับคำค้นหา"
                    setTextColor(pal.fg)
                    setPadding(dp(4), dp(12), 0, 0)
                })
            }
            shown.forEachIndexed { i, app ->
                val row = buildRow(app)
                list.addView(row)
                if (animate) {
                    row.alpha = 0f
                    row.translationY = dp(16).toFloat()
                    row.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setStartDelay(min(i, 10) * 35L)
                        .setDuration(280)
                        .start()
                }
            }
        }

        // คืนค่าคำค้นหาเดิมตอนกลับมาจากหน้าตั้งค่า
        if (searchQuery.isNotEmpty()) {
            search.setText(searchQuery)
            search.setSelection(search.text.length)
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString() ?: ""
                render(searchQuery, false)
            }
        })
        render(searchQuery, true)

        root.addView(heading("เครื่องมือและช่องทางติดต่อ", 16f))
        root.addView(button("เชื่อมต่อ / ขอสิทธิ์ Shizuku", 1) { requestShizuku() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        root.addView(button("ติดต่อผู้พัฒนา TikTok @k_a_e_w.01") {
            openLink("https://www.tiktok.com/@k_a_e_w.01")
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        root.addView(button("วิธีเชื่อมต่อ Shizuku (TikTok)") {
            openLink("https://vt.tiktok.com/ZSsrG4UAQ/")
        }, LinearLayout.LayoutParams(-1, dp(50)))
    }

    // ---------- หน้าตั้งค่า DPI ของแอป ----------

    private fun showSettings(app: AppEntry) {
        hideKeyboard()
        selected = app
        redraw = { showSettings(app) }
        makeRoot()
        root.addView(topBar())

        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(24))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = cardBg(dp(20).toFloat())
        }
        card.addView(ImageView(this).apply { setImageDrawable(app.icon) }, LinearLayout.LayoutParams(dp(54), dp(54)))
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        names.addView(TextView(this).apply {
            this.text = app.label
            textSize = 19f
            setTextColor(pal.fg)
            typeface = Typeface.DEFAULT_BOLD
        })
        names.addView(TextView(this).apply {
            this.text = app.packageName
            textSize = 12f
            setTextColor(pal.fgHint)
        })
        card.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(card)

        body.addView(heading("ตั้งค่า DPI", 18f))

        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(pal.fg)
            textSize = 26f
            gravity = Gravity.CENTER
            hint = "เช่น 600"
            setHintTextColor(pal.fgHint)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(pal.inputBg)
                setStroke(dp(1), pal.cardStroke)
            }
            val saved = prefs.getInt(key(app), 0)
            if (saved > 0) setText(saved.toString())
        }
        body.addView(input, LinearLayout.LayoutParams(-1, dp(66)))

        body.addView(TextView(this).apply {
            this.text = "ค่าที่บันทึกจะผูกกับแอปนี้เท่านั้น\nหมายเหตุ: ค่านี้เป็นโปรไฟล์ DPI ในแอป ไม่ได้เปลี่ยน DPI ระบบของเกมโดยตรง"
            textSize = 13f
            setTextColor(pal.fgSub)
            setPadding(dp(2), dp(12), 0, dp(8))
        })

        body.addView(button("บันทึกการตั้งค่า") {
            val value = input.text.toString().toIntOrNull()
            if (value == null || value !in 1..2000) {
                Toast.makeText(this, "กรุณากรอก DPI ระหว่าง 1 ถึง 2000", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putInt(key(app), value).apply()
                Toast.makeText(this, "บันทึก DPI $value แล้ว", Toast.LENGTH_SHORT).show()
                showSettings(app)
            }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        body.addView(button("เชื่อมต่อ / ขอสิทธิ์ Shizuku", 1) { requestShizuku() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })

        body.addView(button("ใช้ค่า DPI นี้กับระบบ (Shizuku)") {
            val value = input.text.toString().toIntOrNull()
            if (value == null || value !in 1..2000) {
                Toast.makeText(this, "กรุณากรอก DPI ระหว่าง 1 ถึง 2000", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit().putInt(key(app), value).apply()
                applySystemDpi(value)
            }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        body.addView(button("เข้าเกม ${app.label}") { launchApp(app) },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        body.addView(button("ลบการตั้งค่า DPI", 2) {
            prefs.edit().remove(key(app)).apply()
            Toast.makeText(this, "ลบโปรไฟล์แล้ว", Toast.LENGTH_SHORT).show()
            showSettings(app)
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })

        body.addView(button("ติดต่อผู้พัฒนา TikTok @k_a_e_w.01", 1) {
            openLink("https://www.tiktok.com/@k_a_e_w.01")
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })

        body.addView(button("วิธีเชื่อมต่อ Shizuku (TikTok)", 1) {
            openLink("https://vt.tiktok.com/ZSsrG4UAQ/")
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) })

        body.addView(button("กลับไปเลือกรายชื่อแอป", 1) { showAppList() },
            LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
    }

    private fun launchApp(app: AppEntry) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            Toast.makeText(this, "แอปนี้ไม่มีหน้าสำหรับเปิดจาก Launcher", Toast.LENGTH_LONG).show()
        } else {
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "เปิดแอปไม่สำเร็จ", Toast.LENGTH_LONG).show()
            }
        }
    }
}

/**
 * พื้นหลังอนิเมะที่ขยับได้: ท้องฟ้าไล่สี, ดวงจันทร์/ดวงอาทิตย์เรืองแสง,
 * ดาวกะพริบ + ดาวตก (โหมดดำ) หรือฟองแสงลอย (โหมดขาว), กลีบซากุระร่วง และคลื่นเนินซ้อนชั้น
 */
class AnimeBackgroundView(context: Context, private val dark: Boolean) : View(context) {
    private val dens = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val t0 = SystemClock.uptimeMillis()

    private val petalCount = 26
    private val petalX = FloatArray(petalCount)
    private val petalY = FloatArray(petalCount)
    private val petalSize = FloatArray(petalCount)
    private val petalSpeed = FloatArray(petalCount)
    private val petalPhase = FloatArray(petalCount)

    private val starCount = 55
    private val starX = FloatArray(starCount)
    private val starY = FloatArray(starCount)
    private val starSize = FloatArray(starCount)
    private val starPhase = FloatArray(starCount)

    private var sky: LinearGradient? = null
    private var glow: RadialGradient? = null
    private var orbX = 0f
    private var orbY = 0f
    private var orbR = 0f

    private val petalColorA = if (dark) Color.argb(210, 255, 183, 205) else Color.argb(235, 255, 150, 185)
    private val petalColorB = if (dark) Color.argb(200, 255, 226, 236) else Color.argb(225, 255, 205, 222)

    init {
        val r = Random(11)
        for (i in 0 until petalCount) {
            petalX[i] = r.nextFloat()
            petalY[i] = r.nextFloat()
            petalSize[i] = 7f + r.nextFloat() * 9f
            petalSpeed[i] = 0.025f + r.nextFloat() * 0.04f
            petalPhase[i] = r.nextFloat() * TWO_PI
        }
        for (i in 0 until starCount) {
            starX[i] = r.nextFloat()
            starY[i] = r.nextFloat()
            starSize[i] = 0.7f + r.nextFloat() * 1.4f
            starPhase[i] = r.nextFloat() * TWO_PI
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val colors = if (dark) {
            intArrayOf(Color.parseColor("#04050C"), Color.parseColor("#0C1233"), Color.parseColor("#26124A"))
        } else {
            intArrayOf(Color.parseColor("#FFF0F6"), Color.parseColor("#E6F0FF"), Color.parseColor("#D3E3FF"))
        }
        sky = LinearGradient(0f, 0f, 0f, h.toFloat(), colors, null, Shader.TileMode.CLAMP)
        orbX = w * 0.78f
        orbY = h * 0.13f
        orbR = min(w, h) * 0.5f
        val core = if (dark) Color.argb(125, 190, 170, 255) else Color.argb(160, 255, 214, 160)
        val edge = if (dark) Color.argb(0, 190, 170, 255) else Color.argb(0, 255, 214, 160)
        glow = RadialGradient(orbX, orbY, orbR, core, edge, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val t = (SystemClock.uptimeMillis() - t0) / 1000f

        // ท้องฟ้า
        paint.style = Paint.Style.FILL
        paint.shader = sky
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // ดวงจันทร์ / ดวงอาทิตย์ เรืองแสงเต้นช้า ๆ
        val pulse = 1f + 0.05f * sin(t * 0.8f)
        canvas.save()
        canvas.scale(pulse, pulse, orbX, orbY)
        paint.shader = glow
        canvas.drawCircle(orbX, orbY, orbR, paint)
        paint.shader = null
        paint.color = if (dark) Color.argb(235, 244, 240, 255) else Color.argb(225, 255, 236, 200)
        canvas.drawCircle(orbX, orbY, orbR * 0.2f, paint)
        canvas.restore()

        if (dark) {
            // ดาวกะพริบ
            for (i in 0 until starCount) {
                val a = 0.25f + 0.75f * abs(sin(t * (0.6f + starPhase[i] * 0.1f) + starPhase[i]))
                paint.color = Color.argb((a * 255f).toInt(), 255, 255, 255)
                canvas.drawCircle(starX[i] * w, starY[i] * h * 0.7f, starSize[i] * dens, paint)
            }
            // ดาวตกทุก 8 วินาที
            val cyc = t % 8f
            if (cyc < 1f) {
                val sx = w * (0.85f - 0.55f * cyc)
                val sy = h * (0.04f + 0.18f * cyc)
                paint.strokeWidth = 2.5f * dens
                paint.color = Color.argb(((1f - cyc) * 220f).toInt(), 255, 255, 255)
                canvas.drawLine(sx, sy, sx + w * 0.12f, sy - h * 0.04f, paint)
            }
        } else {
            // ฟองแสงลอยขึ้น
            for (i in 0 until 18) {
                val rise = (starY[i] + t * 0.02f * (0.5f + starPhase[i] * 0.1f)) % 1f
                val by = (1f - rise) * h
                val bx = (starX[i] + 0.02f * sin(t * 0.5f + starPhase[i])) * w
                paint.color = Color.argb(60, 255, 170, 205)
                canvas.drawCircle(bx, by, (6f + starSize[i] * 7f) * dens, paint)
            }
        }

        // กลีบซากุระร่วง
        for (i in 0 until petalCount) {
            val prog = (petalY[i] + t * petalSpeed[i]) % 1f
            val cy = prog * (h + 40f * dens) - 20f * dens
            val drift = petalX[i] + t * 0.012f + 0.04f * sin(t * 0.7f + petalPhase[i])
            val cx = (((drift % 1f) + 1f) % 1f) * w
            val s = petalSize[i] * dens
            val ang = (t * 35f * (0.5f + petalPhase[i] * 0.15f) + petalPhase[i] * 57f) % 360f
            val flutter = 0.55f + 0.45f * abs(sin(t * 1.3f + petalPhase[i]))
            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(ang)
            rect.set(-s, -s * 0.5f * flutter, s, s * 0.5f * flutter)
            paint.color = petalColorA
            canvas.drawOval(rect, paint)
            rect.set(-s * 0.6f, -s * 0.25f * flutter, s * 0.9f, s * 0.2f * flutter)
            paint.color = petalColorB
            canvas.drawOval(rect, paint)
            canvas.restore()
        }

        // เนินคลื่นซ้อนชั้นด้านล่าง
        val wave1 = if (dark) Color.argb(120, 40, 24, 88) else Color.argb(110, 190, 170, 255)
        val wave2 = if (dark) Color.argb(170, 14, 10, 40) else Color.argb(150, 160, 190, 255)
        drawWave(canvas, w, h, h * 0.86f, 18f * dens, w * 0.9f, 0.5f, t, wave1)
        drawWave(canvas, w, h, h * 0.92f, 14f * dens, w * 0.6f, -0.7f, t + 2f, wave2)

        postInvalidateOnAnimation()
    }

    private fun drawWave(
        canvas: Canvas, w: Float, h: Float, baseY: Float, amp: Float,
        wl: Float, speed: Float, t: Float, color: Int
    ) {
        path.reset()
        path.moveTo(0f, h)
        var x = 0f
        while (x <= w + 16f) {
            val y = baseY + amp * sin(x / wl * TWO_PI + t * speed)
            path.lineTo(x, y)
            x += 16f
        }
        path.lineTo(w + 16f, h)
        path.close()
        paint.color = color
        canvas.drawPath(path, paint)
    }
}
